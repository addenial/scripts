export PATH="`pwd`:$PATH"

